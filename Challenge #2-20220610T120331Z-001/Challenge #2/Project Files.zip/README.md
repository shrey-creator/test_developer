# Typography

Poppins - Regular and Bold
https://fonts.google.com/specimen/Poppins?query=poppins

# Colors

- Background color - #EFF0F6
- Border Color - #D7D7F9
- Primary - #6B00F5
- Pattens Blue - #e1f1fe
- Pale Rose - #ffe2f0
- Ghost White - #f7f7fe
- White Ice - #defef0

# Content

- French Fries with Ketchup - $2.23
- Salmon and Vegetables - $5.12
- Spaghetti with Meat Sauce - $7.82
- Chicken Salad with Parmesean - $6.98
- Fish Sticks and Fries - $6.34
- Ravioli - $6.45
- Tortellini - $6.05
- Bacon, Eggs, and Toast - $5.99
